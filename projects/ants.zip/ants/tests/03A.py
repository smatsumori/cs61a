test = {
  'name': 'Problem 3A',
  'partner': 'A',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'answer': 'd21f3a6075cc741a42d6d6ce12e5aed9',
          'choices': [
            'Always; after adding the insect, reduce its armor to 0 if it is not watersafe',
            'Only if the insect is watersafe; if it is not watersafe, reduce its armor to 0',
            'Only if the insect is watersafe; if it is not watersafe, remove the insect from the place',
            'Never; no insect can be placed in a Water Place'
          ],
          'hidden': False,
          'locked': True,
          'question': 'When should an insect be added to a Water Place?'
        },
        {
          'answer': 'fae228bbdefaf89611ef0df5ee7e8225',
          'choices': [
            'class attribute',
            'instance attribute'
          ],
          'hidden': False,
          'locked': True,
          'question': 'What type of attribute should "watersafe" be?'
        },
        {
          'answer': '127cd87858e6c0a9f29f199fb2e2be0a',
          'choices': [
            'reduce_armor, in the Insect class',
            'remove_insect, in the Place class',
            'sting, in the Bee class',
            'action, in the Insect class',
            'remove_ant, in the AntColony class'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          What method deals damage to an Insect and removes it from
          its Place? (You should use this method in your code.)
          """
        }
      ],
      'scored': False,
      'type': 'concept'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> # Testing water with Ants
          >>> test_ants = [HarvesterAnt(), Ant(), ThrowerAnt()]
          >>> test_water = Water('Water Test1')
          >>> for test_ant in test_ants:
          ...     test_water.add_insect(test_ant)
          ...     assert test_ant.armor == 0,\
          ...             '{0} should have 0 armor'.format(test_ant)
          ...     assert test_water.ant is None,\
          ...             '{0} not removed from water'.format(test_ant)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from ants import *
      >>> hive, layout = Hive(make_test_assault_plan()), dry_layout
      >>> dimensions = (1, 9)
      >>> colony = AntColony(None, hive, ant_types(), layout, dimensions)
      """,
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> # Testing water inheritance
          >>> def new_add_insect(self, insect):
          ...     raise NotImplementedError()
          
          >>> Place.add_insect = new_add_insect
          >>> test_bee = Bee(1)
          >>> test_water = Water('Water Test4')
          >>> passed = False
          >>> try:
          ...     test_water.add_insect(test_bee)
          ... except NotImplementedError:
          ...     passed = True
          >>> passed
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from ants import *
      >>> hive, layout = Hive(make_test_assault_plan()), dry_layout
      >>> dimensions = (1, 9)
      >>> colony = AntColony(None, hive, ant_types(), layout, dimensions)
      >>> old_add_insect = Place.add_insect
      """,
      'teardown': r"""
      >>> Place.add_insect = old_add_insect
      """,
      'type': 'doctest'
    }
  ]
}
