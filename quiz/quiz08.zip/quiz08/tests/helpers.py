test = {
  'name': 'Helpers',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          scm> (predicate '((> x 3) (+ y 2)))
          5dd21f2ee15fb2658deedfd25da0a430
          # locked
          scm> (predicate '(else x))
          7d5c98ce1807725a212f422ec1a85464
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': True,
      'setup': r"""
      scm> (load 'quiz08)
      """,
      'teardown': '',
      'type': 'scheme'
    },
    {
      'cases': [
        {
          'code': r"""
          scm> (consequent '((> x 3) (+ y 2)))
          d4c43b24456118cba5b1cce18bc1ea18
          # locked
          scm> (consequent '(else x))
          a481a458a4b167f254bb1c5ce6244ae1
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': True,
      'setup': r"""
      scm> (load 'quiz08)
      """,
      'teardown': '',
      'type': 'scheme'
    },
    {
      'cases': [
        {
          'code': r"""
          scm> (first-clause '(cond (else 4)))  ; Type () if you think this is the empty list.
          f30b6d2006ad01361e2a7e82278ea4ea
          # locked
          scm> (first-clause '(cond ((< x 3) (+ x 3)) ((= x 3) x) (else (- x 3))))
          82b55a7bb20237f9153271c8eb8a6c3f
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': True,
      'setup': r"""
      scm> (load 'quiz08)
      """,
      'teardown': '',
      'type': 'scheme'
    },
    {
      'cases': [
        {
          'code': r"""
          scm> (rest-clauses '(cond (else 4)))  ; Type () if you think this is the empty list.
          448e603d484a3bce1e10e057c3078159
          # locked
          scm> (rest-clauses '(cond ((< x 3) (+ x 3)) ((= x 3) x) (else (- x 3))))
          88599e79f39f60e97bfcf2abff5b5a91
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': True,
      'setup': r"""
      scm> (load 'quiz08)
      """,
      'teardown': '',
      'type': 'scheme'
    }
  ]
}
